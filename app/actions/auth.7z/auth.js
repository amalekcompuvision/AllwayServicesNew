export const SIGNUP = 'SIGNUP';
export const LOGIN = 'LOGIN';
export const SET_USER_DATA = 'SET_USER_DATA';
export const SET_STATUS = 'SET_STATUS';


import { useState } from 'react';
import { store } from '../store/index';

const baseUrl ='https://www.allwaytaxi.com/api';
const token ='sb23oc-Moas|Kallwayu';


// import AsyncStorage from '@react-native-async-storage/async-storage';

// storeData = async (key, data, key1, data1) => {
//   try {
//     await AsyncStorage.setItem(key, data);
//     await AsyncStorage.setItem(key1, data1);
//   } catch (error) {}
// };

// export const fetchUserInfo = (email, password) => {
    
//   // eslint-disable-next-line prettier/prettier
//   const token ='sb23oc-Moas|Kallwayu';
// return async dispatch =>{
//   const response = await fetch(
//   `http://192.168.1.105/allwayservices/api/driverlogin.php?token=${token}&password=${password}&email=${email}`
//   );
//   const resData = await response.json();
//   console.log(resData);  
//   if (resData.result == 1) {
//       store.dispatch(setUserInfo(resData));
//       console.log('user data dispatched')
//   }
//   else {Alert.alert(resData.message);
    
//   }
// }
// };

// export const signup = (email, password) => {
//   const token ='sb23oc-Moas|Kallwayu';

//   return async dispatch => {
//     const response = await fetch(
//       `http://192.168.1.105/allwayservices/api/driverlogin.php?token=${token}&password=${password}&email=${email}`

//     );

//     if (!response.ok) {
//       const errorResData = await response.json();
//       const errorId = errorResData.error.message;
//       let message = 'Something went wrong!';
//       if (errorId === 'EMAIL_EXISTS') {
//         message = 'This email exists already!';
//       }
//       throw new Error(message);
//     }

//     const resData = await response.json();
//     console.log(resData);
//     dispatch({ type: SIGNUP, token: resData.idToken, userId: resData.localId });
//   };
// };

export const setStatus = (id, status) => {
  // console.log(`https://www.allwaytaxi.com/api/driverlogin.php?token=${token}&password=${password}&email=${email}`)
  let intStatus = 0;
  if (status == true) {
   intStatus = 1; 
  }
  else{
    intStatus = 0;
  }
  return async (dispatch) => {
    console.log('url issssssssssssssmmmmmmmmmmmmmmmmmmmmmmssss');
    console.log(`${baseUrl}/driverstatus.php?token=${token}&driver_id=${id}&status=${intStatus}`)
    const response = await fetch(
      // `${baseUrl}/driverlogin.php?token=${token}&password=${password}&email=${email}`);
      `${baseUrl}/driverstatus.php?token=${token}&driver_id=${id}&status=${status}`
      );
    const resData = await response.json();

    console.log(resData);
    if (resData.result == 0) {
      const errorResData = await response.json();
      const errorId = errorResData.resData.message;
      // let message = 'Something went wrong!';
      // if (errorId === '"Wrong Email or Password"') {
      //   message = 'the email or password is invalid!';
      // } else if (errorId === '"Wrong Email or Password"') {
      //   message = 'the email or password is not valid!';
      // }
      console.log(errorId);
      throw new Error('Something is wrong');
    }

    if (resData.message == 'Successfully Activated') {
      
      dispatch({ 
        type: SET_STATUS,
        //  token: resData.idToken,
          statusChanged: true,
      });
    }
    else if (resData.message == 'Successfully Deactivated') {
      dispatch({ 
        type: SET_STATUS,
        //  token: resData.idToken,
          statusChanged: false,
      });
    }



    // dispatch({ 
    //   type: SET_USER_DATA ,
    //   //  token: resData.idToken,
    //     userInfo: {
    //     id:    resData.id,
    //     fname: resData.fname,
    //     lname: resData.lname,
    //     email: resData.email,
    //     phone: resData.phone,
    //     }

      
      // });
      // storeData(
      //   'conname',
      //   resData.email,
      //   'conpass',
      //   password
      // );
  };

  
};
export const login = (email, password) => {
  // console.log(`https://www.allwaytaxi.com/api/driverlogin.php?token=${token}&password=${password}&email=${email}`)

  return async (dispatch) => {
    const response = await fetch(
      `${baseUrl}/driverlogin.php?token=${token}&password=${password}&email=${email}`);
      // ${baseUrl}/driverstatus.php?token=${token}&driver_id=3&status=1
    const resData = await response.json();

    console.log(resData);
    if (resData.result == 0) {
      const errorResData = await response.json();
      const errorId = errorResData.resData.message;
      let message = 'Something went wrong!';
      if (errorId === '"Wrong Email or Password"') {
        message = 'the email or password is invalid!';
      } else if (errorId === '"Wrong Email or Password"') {
        message = 'the email or password is not valid!';
      }
      console.log(message);
      throw new Error('Wrong Email or Password');
    }


    dispatch({ 
      type: LOGIN,
      //  token: resData.idToken,
        userId: resData.id });


    dispatch({ 
      type: SET_USER_DATA ,
      //  token: resData.idToken,
        userInfo: {
        id:    resData.id,
        fname: resData.fname,
        lname: resData.lname,
        email: resData.email,
        phone: resData.phone,
        }

      
      });
      // storeData(
      //   'conname',
      //   resData.email,
      //   'conpass',
      //   password
      // );
  };

  
};
